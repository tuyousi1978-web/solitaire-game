# ソリティア (Klondike Solitaire)

美しいカードデザインを使用した本格的なソリティアゲームです。

## 特徴

- 🎴 オリジナルのカードデザイン
- 📱 iPhone/iPad完全対応（ホーム画面に追加可能）
- 🎮 ドラッグ&ドロップ操作
- ✨ エレガントなアニメーション
- 🏆 勝利時の演出

## 遊び方

### 基本操作
- **カードをめくる**: 左上の「山札」をクリック
- **カードを移動**: ドラッグ&ドロップ
- **自動移動**: カードをダブルクリック（Foundation に移動可能な場合）
- **新しいゲーム**: 「新しいゲーム」ボタンをクリック

### ルール
- タブローでは赤と黒を交互に、降順で並べる
- キングは空の列に置ける
- Foundationにはエースから順番に同じスートを並べる
- 全てのカードをFoundationに移動できればクリア

## GitHub Pagesへのデプロイ方法

### 1. リポジトリの作成
```bash
# 新しいリポジトリを作成
mkdir solitaire-game
cd solitaire-game
git init

# ファイルを配置
# index.html をこのディレクトリにコピー

# コミット
git add .
git commit -m "Initial commit: Add solitaire game"
```

### 2. GitHubにプッシュ
```bash
# GitHubでリポジトリを作成後
git remote add origin https://github.com/yourusername/solitaire-game.git
git branch -M main
git push -u origin main
```

### 3. GitHub Pagesを有効化
1. GitHubリポジトリページで「Settings」をクリック
2. 左メニューから「Pages」を選択
3. Source セクションで:
   - Branch: `main`
   - Folder: `/ (root)`
4. 「Save」をクリック

数分後、`https://yourusername.github.io/solitaire-game/` でアクセス可能になります。

## iPhoneでの使用方法

### ホーム画面に追加
1. Safariでゲームを開く
2. 共有ボタン（□↑）をタップ
3. 「ホーム画面に追加」を選択
4. 「追加」をタップ

これでアプリのように全画面でプレイできます！

## 技術スタック

- Pure HTML/CSS/JavaScript
- Responsive Design
- PWA対応（iOS Web App）
- ドラッグ&ドロップAPI

## ライセンス

このプロジェクトは個人利用・商用利用ともに自由にご利用いただけます。

## 今後の改善予定

- [ ] アンドゥ機能の実装
- [ ] スコア・タイマー機能（オプション）
- [ ] 難易度選択（1枚めくり/3枚めくり）
- [ ] カード裏面デザインの選択機能
- [ ] ダークモード対応

---

Enjoy playing! 🎴✨
